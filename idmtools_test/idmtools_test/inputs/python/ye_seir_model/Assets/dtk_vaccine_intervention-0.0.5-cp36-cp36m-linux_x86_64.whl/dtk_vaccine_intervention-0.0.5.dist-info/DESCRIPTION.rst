# SimpleVaccine Package

This python module wraps the SimpleVaccine intervention.


